document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("executeScript").addEventListener("click", function () {
        const xAuthToken = document.getElementById("xAuthToken").value;
        const refreshToken = document.getElementById("refreshToken").value;

        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            console.log("Tabs:", tabs);
            let tabId = tabs[0].id;
            console.log("Tab ID:", tabId);
            chrome.scripting.executeScript({
                target: { tabId: tabId },
                function: executeScript,
                args: [xAuthToken, refreshToken]
            });
        });
    });
});

function executeScript(xAuthToken, refreshToken) {
    console.log("Executing script with xAuthToken:", xAuthToken, "and refreshToken:", refreshToken);
    window.indexedDB.open("keyval-store", 1).onsuccess = event => {
        setTimeout(() => {
            let db = event.target.result;
            let transaction = db.transaction(["keyval"], "readwrite");
            let objectStore = transaction.objectStore("keyval");

            // Ενημερωμένα δεδομένα με τωρινή ημερομηνία
            const timestamp = Date.now();
            const expiration = timestamp + (30 * 24 * 60 * 60 * 1000); // 30 μέρες από τώρα

            objectStore.put(`{"position":{"lat":"", "lon":"", "timestamp":${timestamp}},"dismissed":false,"__PERSIST__":{"version":1,"timestamp":${timestamp + 100}}}`, "persist::location");
            objectStore.put(`{"authToken":"${xAuthToken}", "authTokenExpiration":${expiration}, "captchaType":"CAPTCHA_INVALID", "funnelSessionId":"","guestAuthToken":"","loginType":"sms", "onboardingUserId":null, "refreshToken":"${refreshToken || ''}", "__PERSIST__":{"version":0, "timestamp":${expiration}}}`, "persist::mfa");
            objectStore.put(`{"loggedIn":true, "__PERSIST__":{"version":2, "timestamp":${expiration}}}`, "persist::user");

            localStorage.setItem("TinderWeb/APIToken", xAuthToken);
            if (refreshToken) localStorage.setItem("TinderWeb/RefreshToken", refreshToken);

            location.reload();
        }, 3000);
    };
}