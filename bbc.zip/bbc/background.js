chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.action === "inject") {
        const { tabId, xAuthToken, refreshToken } = message;
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            function: executeScript,
            args: [xAuthToken, refreshToken]
        }, (results) => {
            if (chrome.runtime.lastError) {
                sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
                sendResponse({ success: true });
            }
        });
        return true; // Keep the message channel open for async response
    }
});

function executeScript(xAuthToken, refreshToken) {
    window.indexedDB.open("keyval-store", 1).onsuccess = event => {
        let db = event.target.result;
        let transaction = db.transaction(["keyval"], "readwrite");
        let objectStore = transaction.objectStore("keyval");

        const timestamp = Date.now();
        const expiration = timestamp + (30 * 24 * 60 * 60 * 1000); // 30 days

        objectStore.put(`{"position":{"lat":"", "lon":"", "timestamp":${timestamp}},"dismissed":false,"__PERSIST__":{"version":1,"timestamp":${timestamp + 100}}}`, "persist::location");
        objectStore.put(`{"authToken":"${xAuthToken}", "authTokenExpiration":${expiration}, "captchaType":"CAPTCHA_INVALID", "funnelSessionId":"","guestAuthToken":"","loginType":"sms", "onboardingUserId":null, "refreshToken":"${refreshToken || ''}", "__PERSIST__":{"version":0, "timestamp":${expiration}}}`, "persist::mfa");
        objectStore.put(`{"loggedIn":true, "__PERSIST__":{"version":2, "timestamp":${expiration}}}`, "persist::user");

        localStorage.setItem("TinderWeb/APIToken", xAuthToken);
        if (refreshToken) localStorage.setItem("TinderWeb/RefreshToken", refreshToken);

        setTimeout(() => {
            const ws = new WebSocket(`wss://keepalive.gotinder.com/ws?token=${xAuthToken}`);
            ws.onopen = () => ws.send(JSON.stringify({ message: "ping" }));
        }, 3000);

        location.reload();
    };
}