document.addEventListener("DOMContentLoaded", function () {
    const statusDiv = document.getElementById("status");

    // Inject Button
    document.getElementById("executeScript").addEventListener("click", function () {
        const xAuthToken = document.getElementById("xAuthToken").value;
        const refreshToken = document.getElementById("refreshToken").value;

        if (!xAuthToken) {
            statusDiv.textContent = "Please enter an X-Auth-Token!";
            statusDiv.className = "error";
            return;
        }

        statusDiv.textContent = "Injecting...";
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            const tabId = tabs[0].id;
            chrome.runtime.sendMessage({
                action: "inject",
                tabId: tabId,
                xAuthToken: xAuthToken,
                refreshToken: refreshToken
            }, function (response) {
                if (chrome.runtime.lastError) {
                    statusDiv.textContent = "Error: " + chrome.runtime.lastError.message;
                    statusDiv.className = "error";
                } else if (response && response.success) {
                    statusDiv.textContent = "Injection successful! Reloading...";
                    statusDiv.className = "success";
                } else {
                    statusDiv.textContent = "Error: " + (response.error || "Unknown error");
                    statusDiv.className = "error";
                }
            });
        });
    });
});