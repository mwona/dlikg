window.onload = function() {
  if (window.location.href.includes("tinder.com")) {
    console.log("Προσπαθώ να σε συνδέσω...");
    chrome.storage.local.get(["userToken", "refreshToken"], function(result) {
      if (result.userToken && result.refreshToken) {
        console.log("Token βρέθηκε: " + result.userToken);
        console.log("Refresh Token βρέθηκε: " + result.refreshToken);
        localStorage.setItem("tinder_token", result.userToken);
        localStorage.setItem("tinder_refresh_token", result.refreshToken);

        fetch("https://api.gotinder.com/auth", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0",
            "X-Auth-Token": result.userToken,
            "Platform": "web"
          },
          body: JSON.stringify({
            token: result.userToken,
            refresh_token: result.refreshToken
          })
        })
        .then(response => {
          console.log("Κωδικός απόκρισης:", response.status);
          return response.text();
        })
        .then(text => {
          console.log("Απάντηση από Tinder:", text);
          if (text) {
            try {
              const data = JSON.parse(text);
              if (data.api_token) {
                localStorage.setItem("tinder_api_token", data.api_token);
                console.log("API Token αποθηκεύτηκε:", data.api_token);
                window.location.reload();
              } else {
                console.log("Δεν βρέθηκε api_token στην απάντηση.");
              }
            } catch (e) {
              console.log("Δεν μπόρεσα να διαβάσω JSON:", e);
              if (text === "OK") {
                console.log("Το Tinder είπε OK, ανανεώνω τη σελίδα...");
                window.location.reload();
              }
            }
          } else {
            console.log("Κενή απάντηση από Tinder.");
          }
        })
        .catch(error => console.log("Σφάλμα σύνδεσης:", error));
      } else {
        console.log("Λείπει token ή refresh token!");
      }
    });
  }
}

// Έλεγχος μετά την ανανέωση
setTimeout(function() {
  if (localStorage.getItem("tinder_token") && !document.querySelector(".logged-in")) {
    console.log("Η σύνδεση δεν πέτυχε ακόμα, δοκιμάζω ξανά...");
    window.location.reload();
  } else if (document.querySelector(".logged-in")) {
    console.log("Είσαι συνδεδεμένος, τέλεια!");
  }
}, 2000);